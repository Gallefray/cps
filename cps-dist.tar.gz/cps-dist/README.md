Check that `Process` is running at a set interval for a set amount of times.  
For more information see the manual page under `man/`  
Licensed under the GPLv2 License.  

Installing:  
Extract `cps-dist.tar.gz`  
Run `cd cps-dist/`  
Run `./configure`  
Run `make`  
Run `make install`  
and it should be installed!   
(This is my first time using the GNU autotools, sorry if I messed up a bit :S)

Enjoy!  
\- Galle
