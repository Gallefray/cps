cps - check process is running.
Licensed under the GPLv2 License.

Installing:
Extract `cps-dist.tar.gz`
Run `cd cps-dist/`
Run `./configure`
Run `make`
Run `make install`
and it should be installed! 
(This is my first time using the GNU autotools, sorry if I messed up a bit :S)

For usage see the manual page, under `man/`

Enjoy!
- Galle
